package br.fiap.Controle;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.fiap.Cliente.ClienteFisico;
import java.sql.Date;

/**
 * Servlet implementation class cadastroClienteFisicoServlet
 */
@WebServlet("/cadastroClienteFisico")
public class CadastroClienteFisicoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nome = request.getParameter("nomeCliente");
		String sobrenome = request.getParameter("sobrenomeCliente");
		String cpf = request.getParameter("cpf");
		String email = request.getParameter("email");
		String sexo = request.getParameter("sexo");
		//Date dataNasc = Date.parse(request.getParameter("dataNasc"));
		Integer telefone  = Integer.parseInt(request.getParameter("telefone"));
		String cep = request.getParameter("cep");
		String rua = request.getParameter("rua");
		String nRua = request.getParameter("numero_rua");
		//String complemento = request.getParameter("complemento");
		String endeco = rua + " - N° " + nRua;
		String senha = request.getParameter("senha");
		
		ClienteFisico cliente = new ClienteFisico(0, nome, email, endeco, telefone, cep, cpf, sobrenome, null);
		
		System.out.println(cliente);
	}

}
